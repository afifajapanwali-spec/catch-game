(() => {
  "use strict";
  const canvas = document.getElementById("game");
  const ctx = canvas.getContext("2d");
  const $ = (id) => document.getElementById(id);
  const ui = {
    score: $("score"), best: $("best"), lives: $("lives"), overlay: $("overlay"),
    title: $("overlayTitle"), text: $("overlayText"), start: $("startBtn"),
    pause: $("pauseBtn"), sound: $("soundBtn"), toast: $("toast")
  };

  const W = 900, H = 600;
  let state = "menu", score = 0, lives = 3, best = 0;
  let objects = [], particles = [], stars = [], lastTime = 0, spawnClock = 0;
  let elapsed = 0, shake = 0, muted = false, audioCtx = null, toastTimer = 0;
  const keys = { left:false, right:false };
  const ship = { x:W/2, y:H-67, w:72, h:48, speed:470 };
  try { best = Math.max(0, Number(localStorage.getItem("galaxyCatcherBest")) || 0); } catch (_) { best = 0; }
  ui.best.textContent = best;

  function makeStars() {
    stars = Array.from({length:145}, () => ({
      x:Math.random()*W, y:Math.random()*H, r:Math.random()*1.7+.25,
      speed:12+Math.random()*35, alpha:.25+Math.random()*.7, phase:Math.random()*6.28
    }));
  }
  makeStars();

  function sound(freq=500, duration=.09, type="sine", volume=.045) {
    if (muted) return;
    try {
      audioCtx ||= new (window.AudioContext || window.webkitAudioContext)();
      if (audioCtx.state === "suspended") audioCtx.resume();
      const osc = audioCtx.createOscillator(), gain = audioCtx.createGain();
      osc.type = type; osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(Math.max(70,freq*.65), audioCtx.currentTime+duration);
      gain.gain.setValueAtTime(volume, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(.001, audioCtx.currentTime+duration);
      osc.connect(gain); gain.connect(audioCtx.destination); osc.start(); osc.stop(audioCtx.currentTime+duration);
    } catch (_) { /* Audio is optional; the game remains playable without it. */ }
  }

  function updateHUD() {
    ui.score.textContent = score;
    ui.best.textContent = best;
    ui.lives.textContent = "♥ ".repeat(lives).trim() || "—";
  }
  function showToast(message) {
    ui.toast.textContent = message; ui.toast.classList.add("show");
    clearTimeout(toastTimer); toastTimer = setTimeout(() => ui.toast.classList.remove("show"), 850);
  }
  function setOverlay(title, message, buttonText) {
    ui.title.textContent = title; ui.text.textContent = message; ui.start.innerHTML = buttonText + " <span>↗</span>";
    ui.overlay.classList.remove("hidden");
  }
  function startGame() {
    score = 0; lives = 3; elapsed = 0; spawnClock = 0; objects = []; particles = [];
    ship.x = W/2; shake = 0; state = "playing"; updateHUD();
    ui.overlay.classList.add("hidden"); ui.pause.disabled = false; ui.pause.innerHTML = "Ⅱ <span>PAUSE</span>";
    sound(520,.13,"triangle");
  }
  function pauseGame() {
    if (state === "playing") {
      state = "paused"; ui.pause.innerHTML = "▶ <span>RESUME</span>";
      setOverlay("Paused in orbit", "Your mission is on hold. Take a breath, then continue.", "RESUME");
    } else if (state === "paused") {
      state = "playing"; ui.overlay.classList.add("hidden"); ui.pause.innerHTML = "Ⅱ <span>PAUSE</span>";
    }
  }
  function endGame() {
    state = "over"; ui.pause.disabled = true;
    if (score > best) {
      best = score;
      try { localStorage.setItem("galaxyCatcherBest", String(best)); } catch (_) {}
    }
    updateHUD(); sound(180,.28,"sawtooth",.035);
    setOverlay("Mission complete", `You collected ${score} stardust points. Your best is ${best}.`, "PLAY AGAIN");
  }
  function spawnObject() {
    const bad = Math.random() < .29;
    const radius = bad ? 18+Math.random()*9 : 15+Math.random()*8;
    objects.push({
      x:radius+Math.random()*(W-radius*2), y:-35, r:radius,
      vy:155+Math.min(220,elapsed*5)+Math.random()*65,
      vx:(Math.random()-.5)*32, rot:Math.random()*6.28, spin:(Math.random()-.5)*2,
      bad, sides:bad ? 8 : 6, seed:Math.random()*100
    });
  }
  function burst(x,y,color,count=14) {
    for (let i=0;i<count;i++) {
      const a=Math.random()*Math.PI*2, speed=45+Math.random()*190;
      particles.push({x,y,vx:Math.cos(a)*speed,vy:Math.sin(a)*speed,life:.35+Math.random()*.5,max:.85,size:2+Math.random()*4,color});
    }
  }
  function loseLife(obj) {
    lives--; shake=13; burst(obj.x,obj.y,"#ff668b",19); sound(125,.22,"sawtooth",.055);
    updateHUD(); showToast("Hazard hit! Watch out!");
    if (lives <= 0) endGame();
  }
  function collect(obj) {
    score += 10; burst(obj.x,obj.y,"#78edff",17); sound(740,.11,"sine",.04);
    if (score > best) { best=score; updateHUD(); }
    else updateHUD();
    showToast("+10 STARDUST");
  }
  function hitTest(obj) {
    const nearestX = Math.max(ship.x-ship.w*.38, Math.min(obj.x, ship.x+ship.w*.38));
    const nearestY = Math.max(ship.y-ship.h*.35, Math.min(obj.y, ship.y+ship.h*.35));
    return Math.hypot(obj.x-nearestX,obj.y-nearestY) < obj.r*.82;
  }
  function update(dt) {
    elapsed += dt;
    stars.forEach(s => { s.y += s.speed*dt; s.phase += dt*2; if(s.y>H){s.y=0;s.x=Math.random()*W;} });
    if (state !== "playing") return;
    if (keys.left) ship.x -= ship.speed*dt;
    if (keys.right) ship.x += ship.speed*dt;
    ship.x = Math.max(ship.w*.55,Math.min(W-ship.w*.55,ship.x));
    spawnClock += dt;
    const interval = Math.max(.38, .92-elapsed*.008);
    while (spawnClock >= interval) { spawnClock -= interval; spawnObject(); }
    for (let i=objects.length-1;i>=0;i--) {
      const o=objects[i]; o.y += o.vy*dt; o.x += o.vx*dt; o.rot += o.spin*dt;
      if (hitTest(o)) {
        if (o.bad) loseLife(o); else collect(o);
        objects.splice(i,1); if(state!=="playing") break;
      } else if(o.y-o.r>H) objects.splice(i,1);
    }
    for(let i=particles.length-1;i>=0;i--){
      const p=particles[i]; p.x+=p.vx*dt; p.y+=p.vy*dt; p.vx*=.985; p.vy*=.985; p.life-=dt;
      if(p.life<=0) particles.splice(i,1);
    }
    shake=Math.max(0,shake-dt*30);
  }

  function polygon(x,y,r,sides,rotation,fill,stroke) {
    ctx.beginPath();
    for(let i=0;i<sides;i++){
      const a=rotation+i*Math.PI*2/sides, wobble=1+Math.sin(i*12.4+x*.02)*.09;
      const px=x+Math.cos(a)*r*wobble, py=y+Math.sin(a)*r*wobble;
      if(i===0)ctx.moveTo(px,py);else ctx.lineTo(px,py);
    }
    ctx.closePath(); ctx.fillStyle=fill; ctx.fill();
    ctx.strokeStyle=stroke; ctx.lineWidth=2; ctx.stroke();
  }
  function drawBackground(t) {
    const g=ctx.createLinearGradient(0,0,0,H); g.addColorStop(0,"#090d32"); g.addColorStop(.55,"#15113d"); g.addColorStop(1,"#090b28");
    ctx.fillStyle=g; ctx.fillRect(0,0,W,H);
    const nebula=ctx.createRadialGradient(W*.25,H*.35,10,W*.25,H*.35,330);
    nebula.addColorStop(0,"rgba(85,69,190,.25)"); nebula.addColorStop(1,"rgba(85,69,190,0)");
    ctx.fillStyle=nebula;ctx.fillRect(0,0,W,H);
    const nebula2=ctx.createRadialGradient(W*.82,H*.62,5,W*.82,H*.62,270);
    nebula2.addColorStop(0,"rgba(27,151,190,.16)");nebula2.addColorStop(1,"rgba(27,151,190,0)");
    ctx.fillStyle=nebula2;ctx.fillRect(0,0,W,H);
    stars.forEach(s=>{
      const twinkle=.65+.35*Math.sin(t*2+s.phase);
      ctx.globalAlpha=s.alpha*twinkle;ctx.fillStyle="#e5f5ff";
      ctx.beginPath();ctx.arc(s.x,s.y,s.r,0,Math.PI*2);ctx.fill();
    });ctx.globalAlpha=1;
    ctx.strokeStyle="rgba(144,153,255,.08)";ctx.lineWidth=1;
    for(let x=0;x<W;x+=75){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,H);ctx.stroke();}
  }
  function drawShip() {
    ctx.save();ctx.translate(ship.x,ship.y);
    ctx.shadowBlur=22;ctx.shadowColor="#6ce7ff";
    ctx.fillStyle="#72e9ff";ctx.beginPath();ctx.moveTo(0,-25);ctx.lineTo(31,19);ctx.lineTo(0,11);ctx.lineTo(-31,19);ctx.closePath();ctx.fill();
    ctx.shadowBlur=0;ctx.fillStyle="#a79aff";ctx.beginPath();ctx.ellipse(0,-3,10,14,0,0,Math.PI*2);ctx.fill();
    ctx.fillStyle="#fff";ctx.beginPath();ctx.ellipse(0,-7,4,7,0,0,Math.PI*2);ctx.fill();
    ctx.fillStyle="#ff9cda";ctx.beginPath();ctx.moveTo(-10,17);ctx.lineTo(-5,34+Math.random()*5);ctx.lineTo(0,18);ctx.fill();
    ctx.beginPath();ctx.moveTo(2,18);ctx.lineTo(8,33+Math.random()*5);ctx.lineTo(11,17);ctx.fill();
    ctx.restore();
  }
  function drawObject(o) {
    ctx.save();ctx.translate(o.x,o.y);ctx.rotate(o.rot);
    if(o.bad){
      ctx.shadowBlur=20;ctx.shadowColor="#ff466f";
      polygon(0,0,o.r,o.sides,0,"#8e294f","#ff8ca6");
      ctx.shadowBlur=0;ctx.fillStyle="#ffb0a7";ctx.beginPath();ctx.arc(-3,-3,4,0,Math.PI*2);ctx.fill();
      ctx.strokeStyle="rgba(255,200,210,.8)";ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(-o.r*.45,o.r*.25);ctx.lineTo(o.r*.35,-o.r*.4);ctx.stroke();
    }else{
      ctx.shadowBlur=23;ctx.shadowColor="#70eaff";
      polygon(0,0,o.r,o.sides,0,"#2588b9","#a9f7ff");
      ctx.shadowBlur=0;ctx.fillStyle="#d5ffff";ctx.beginPath();ctx.arc(-3,-4,o.r*.22,0,Math.PI*2);ctx.fill();
      ctx.strokeStyle="rgba(225,255,255,.7)";ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(-o.r*.4,o.r*.2);ctx.lineTo(o.r*.35,-o.r*.3);ctx.stroke();
    }
    ctx.restore();
  }
  function draw(t) {
    ctx.save();
    if(shake>0)ctx.translate((Math.random()-.5)*shake,(Math.random()-.5)*shake);
    drawBackground(t);
    objects.forEach(drawObject);
    particles.forEach(p=>{ctx.globalAlpha=Math.max(0,p.life/p.max);ctx.fillStyle=p.color;ctx.beginPath();ctx.arc(p.x,p.y,p.size,0,Math.PI*2);ctx.fill();});
    ctx.globalAlpha=1;
    drawShip();
    ctx.restore();
  }
  function loop(timestamp) {
    const dt=Math.min(.034,Math.max(0,(timestamp-lastTime)/1000 || 0));lastTime=timestamp;
    update(dt);draw(timestamp/1000);requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);

  function setMove(direction, pressed) { keys[direction]=pressed; }
  document.addEventListener("keydown",e=>{
    if(["ArrowLeft","ArrowRight"," "].includes(e.key))e.preventDefault();
    if(e.key==="ArrowLeft"||e.key.toLowerCase()==="a")setMove("left",true);
    if(e.key==="ArrowRight"||e.key.toLowerCase()==="d")setMove("right",true);
    if((e.key===" "||e.key.toLowerCase()==="p")&&!e.repeat){if(state==="playing"||state==="paused")pauseGame();}
    if(e.key==="Enter"&&(state==="menu"||state==="over"))startGame();
  });
  document.addEventListener("keyup",e=>{
    if(e.key==="ArrowLeft"||e.key.toLowerCase()==="a")setMove("left",false);
    if(e.key==="ArrowRight"||e.key.toLowerCase()==="d")setMove("right",false);
  });
  window.addEventListener("blur",()=>{keys.left=false;keys.right=false;if(state==="playing")pauseGame();});
  function bindHold(id,dir){
    const btn=$(id);
    btn.addEventListener("pointerdown",e=>{e.preventDefault();btn.setPointerCapture?.(e.pointerId);setMove(dir,true);});
    ["pointerup","pointercancel","lostpointercapture"].forEach(type=>btn.addEventListener(type,()=>setMove(dir,false)));
  }
  bindHold("leftBtn","left");bindHold("rightBtn","right");
  ui.start.addEventListener("click",()=>{if(state==="paused"){state="playing";ui.overlay.classList.add("hidden");ui.pause.innerHTML="Ⅱ <span>PAUSE</span>";}else startGame();});
  ui.pause.addEventListener("click",pauseGame);
  ui.sound.addEventListener("click",()=>{
    muted=!muted;ui.sound.innerHTML=muted?"♫ <span>OFF</span>":"♫ <span>ON</span>";
    ui.sound.setAttribute("aria-label",muted?"Turn sound on":"Turn sound off");
    if(!muted)sound(620,.08);
  });
  updateHUD();
})();
